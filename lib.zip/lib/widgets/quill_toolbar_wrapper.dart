import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;

class QuillToolbarWrapper extends StatelessWidget {
  final quill.QuillController controller;
  final Color panelColor;
  final VoidCallback onOpenFlagMenu;
  final VoidCallback onLink;

  const QuillToolbarWrapper({
    super.key,
    required this.controller,
    required this.panelColor,
    required this.onOpenFlagMenu,
    required this.onLink,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: panelColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Wrap(
        spacing: 4,
        runSpacing: 4,
        children: [
          _formatButton(Icons.format_bold, 'Bold', quill.Attribute.bold),
          _formatButton(Icons.format_italic, 'Italic', quill.Attribute.italic),
          _formatButton(Icons.format_underlined, 'Underline', quill.Attribute.underline),
          _formatButton(Icons.format_strikethrough, 'Strikethrough', quill.Attribute.strikeThrough),
          const SizedBox(width: 8, height: 32, child: VerticalDivider(color: Colors.grey)),
          _formatButton(Icons.title, 'Heading', quill.Attribute.h2),
          const SizedBox(width: 8, height: 32, child: VerticalDivider(color: Colors.grey)),
          _customButton(Icons.link, 'Link', onLink),
          _customButton(Icons.flag, 'Flag', onOpenFlagMenu),
        ],
      ),
    );
  }

  Widget _formatButton(IconData icon, String tooltip, quill.Attribute attribute) {
    return IconButton(
      icon: Icon(icon, size: 18, color: Colors.white),
      tooltip: tooltip,
      onPressed: () {
        controller.formatSelection(attribute);
      },
      padding: const EdgeInsets.all(4),
      constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
    );
  }

  Widget _customButton(IconData icon, String tooltip, VoidCallback onPressed) {
    return IconButton(
      icon: Icon(icon, size: 18, color: Colors.white),
      tooltip: tooltip,
      onPressed: onPressed,
      padding: const EdgeInsets.all(4),
      constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
    );
  }
}