import 'dart:convert';
import 'package:arted/infobox_panel.dart';
import 'package:arted/models/articles.dart';
import 'package:flutter/material.dart';
import 'package:arted/app_database.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;

class WorkspaceController {
  final TextEditingController titleController = TextEditingController();
  
  // CHANGED: QuillController instead of TextEditingController
  late quill.QuillController contentController;
  
  final List<TocEntry> tocEntries = [];
  final List<Article> articles = [];
  final List<String> categories = [];
  final List<Article> openTabs = [];
  
  Article? selectedArticle;
  bool _infoboxDirty = false;
  bool isViewMode = false;

  String originalContent = "";
  String originalTitle = "";
  
  final ValueNotifier<Article?> hoveredArticle = ValueNotifier(null);
  final ValueNotifier<String?> hoveredCategory = ValueNotifier(null);

  DateTime? lastSaved;

  WorkspaceController() {
    // Initialize with empty document
    contentController = quill.QuillController.basic();
  }

  String generateHeadingId() => _generateHeadingId();

  String _generateHeadingId() {
    return "h_${DateTime.now().microsecondsSinceEpoch}";
  }

  void dispose() {
    titleController.dispose();
    contentController.dispose();
    hoveredArticle.dispose();
    hoveredCategory.dispose();
  }

  void initialize(Function refreshUI, String projectId) {
    contentController.addListener(() {
      rebuildTocFromContent();
    });

    _loadCategories(refreshUI, projectId).then((_) {
      _loadArticles(refreshUI, projectId);
    });
  }

  void markInfoboxDirty() {
    _infoboxDirty = true;
  }

  void clearDirtyFlags() {
    _infoboxDirty = false;
  }

  // ═══════════════════════════════════════════════════════════
  // MARKDOWN TO DELTA CONVERSION
  // ═══════════════════════════════════════════════════════════

  static quill.Delta _markdownToDelta(String markdown) {
    final delta = quill.Delta();
    
    if (markdown.isEmpty) {
      return delta;
    }

    final lines = markdown.split('\n');
    
    for (int i = 0; i < lines.length; i++) {
      final line = lines[i];
      
      // Handle alignment directives
      if (line.startsWith('[align:')) {
        continue; // Skip - we'll implement alignment later if needed
      }
      
      // Handle headings
      if (line.startsWith('## ')) {
        final text = _stripHeadingId(line.substring(3).trim());
        delta.insert(text);
        delta.insert('\n', {'header': 2});
        continue;
      }
      
      // Handle regular lines with inline formatting
      if (line.isNotEmpty) {
        _processInlineFormatting(delta, line);
      }
      
      // Add newline (except for last line if empty)
      if (i < lines.length - 1 || line.isNotEmpty) {
        delta.insert('\n');
      }
    }
    
    return delta;
  }

  static String _stripHeadingId(String text) {
    // Remove {#id} markers from headings
    return text.replaceAll(RegExp(r'\{#.*?\}'), '').trim();
  }

  static void _processInlineFormatting(quill.Delta delta, String line) {
    // Regex to match formatting markers
    final regex = RegExp(
      r'(\*\*.*?\*\*|__.*?__|~~.*?~~|\^.*?\^|~(?!~).*?~|_.*?_|\[\[.*?\]\]|\[flag:[A-Z0-9]{2,3}\])',
    );

    int lastIndex = 0;

    for (final match in regex.allMatches(line)) {
      // Add plain text before match
      if (match.start > lastIndex) {
        delta.insert(line.substring(lastIndex, match.start));
      }

      final token = match.group(0)!;
      
      if (token.startsWith('**')) {
        final text = token.substring(2, token.length - 2);
        delta.insert(text, {'bold': true});
      } else if (token.startsWith('__')) {
        final text = token.substring(2, token.length - 2);
        delta.insert(text, {'underline': true});
      } else if (token.startsWith('~~')) {
        final text = token.substring(2, token.length - 2);
        delta.insert(text, {'strike': true});
      } else if (token.startsWith('^')) {
        final text = token.substring(1, token.length - 1);
        delta.insert(text, {'script': 'super'});
      } else if (token.startsWith('~') && !token.startsWith('~~')) {
        final text = token.substring(1, token.length - 1);
        delta.insert(text, {'script': 'sub'});
      } else if (token.startsWith('_') && !token.startsWith('__')) {
        final text = token.substring(1, token.length - 1);
        delta.insert(text, {'italic': true});
      } else if (token.startsWith('[[')) {
        final content = token.substring(2, token.length - 2);
        final parts = content.split('|');
        final displayText = parts.first;
        final linkTarget = parts.length > 1 ? parts.last : parts.first;
        delta.insert(displayText, {'link': linkTarget});
      } else if (token.startsWith('[flag:')) {
        // Preserve flag markers as-is
        delta.insert(token);
      }

      lastIndex = match.end;
    }

    // Add remaining text
    if (lastIndex < line.length) {
      delta.insert(line.substring(lastIndex));
    }
  }

  // ═══════════════════════════════════════════════════════════
  // DELTA JSON STORAGE
  // ═══════════════════════════════════════════════════════════

  String _deltaToJson(quill.Delta delta) {
    return jsonEncode(delta.toJson());
  }

  quill.Delta _deltaFromJson(String json) {
    if (json.isEmpty) {
      return quill.Delta();
    }
    
    try {
      // Try to parse as JSON (new format)
      final decoded = jsonDecode(json);
      if (decoded is List) {
        return quill.Delta.fromJson(decoded);
      }
    } catch (e) {
      // Not JSON - treat as markdown
    }
    
    // Fall back to markdown conversion
    return _markdownToDelta(json);
  }

  // ═══════════════════════════════════════════════════════════
  // ARTICLE LOADING & SAVING
  // ═══════════════════════════════════════════════════════════

  Future<void> _loadCategories(Function refreshUI, String projectId) async {
    final db = await AppDatabase.database;
    final rows = await db.query(
      'categories',
      where: 'project_id = ?',
      whereArgs: [projectId],
      orderBy: 'name ASC',
    );

    categories
      ..clear()
      ..addAll(rows.map((r) => r['name'] as String));

    if (!categories.contains('Uncategorized')) {
      categories.insert(0, 'Uncategorized');
    }

    refreshUI();
  }

  Future<void> _loadArticles(Function refreshUI, String projectId) async {
    final db = await AppDatabase.database;

    final rows = await db.query(
      'articles',
      where: 'project_id = ?',
      whereArgs: [projectId],
      orderBy: 'created_at ASC',
    );

    articles
      ..clear()
      ..addAll(
        rows.map((row) {
          return Article(
            id: row['id'] as String,
            title: row['title'] as String,
            category: row['category'] as String,
            content: row['content'] as String,
            createdAt: DateTime.fromMillisecondsSinceEpoch(
              row['created_at'] as int,
            ),
            infobox: {},
          );
        }),
      );

    if (articles.isNotEmpty) {
      selectedArticle = articles.first;
      openTabs
        ..clear()
        ..add(selectedArticle!);

      _loadArticle(selectedArticle!);
      await _loadInfoboxBlocks(selectedArticle!);
    }

    refreshUI();
  }

  void _loadArticle(Article article) {
    titleController.text = article.title;
    
    // Load content as Delta
    final delta = _deltaFromJson(article.content);
    contentController = quill.QuillController(
      document: quill.Document.fromDelta(delta),
      selection: const TextSelection.collapsed(offset: 0),
    );

    // Rebuild TOC
    rebuildTocFromContent();

    originalContent = article.content;
    originalTitle = article.title;
  }

  void openArticleByTitle(String title, Function refreshUI) async {
    if (articles.isEmpty) return;

    selectedArticle = articles.firstWhere(
      (a) => a.title == title,
      orElse: () => articles.first,
    );

    _loadArticle(selectedArticle!);
    await _loadInfoboxBlocks(selectedArticle!);

    refreshUI();
  }

  Future<bool> requestArticleSwitch(
    Article target,
    Future<void> Function() onSave,
  ) async {
    if (!hasUnsavedChanges) {
      _loadArticle(target);
      await _loadInfoboxBlocks(target);
      return true;
    }

    return false;
  }

  bool get hasUnsavedChanges {
    if (selectedArticle == null) return false;

    final currentJson = _deltaToJson(contentController.document.toDelta());
    
    return currentJson != originalContent ||
        titleController.text != originalTitle ||
        _infoboxDirty;
  }

  Future<void> saveArticle(String projectId, Function refreshUI) async {
    final db = await AppDatabase.database;
    final a = selectedArticle!;

    final deltaJson = _deltaToJson(contentController.document.toDelta());

    final exists = await db.query(
      'articles',
      where: 'id = ?',
      whereArgs: [a.id],
    );

    final data = {
      'project_id': projectId,
      'title': titleController.text.trim(),
      'content': deltaJson,
      'category': a.category,
    };

    if (exists.isEmpty) {
      await db.insert('articles', {
        'id': a.id,
        'created_at': a.createdAt.millisecondsSinceEpoch,
        ...data,
      });
    } else {
      await db.update('articles', data, where: 'id = ?', whereArgs: [a.id]);
    }

    await saveInfoboxBlocks(a);

    await db.update(
      'projects',
      {'updated_at': DateTime.now().millisecondsSinceEpoch},
      where: 'id = ?',
      whereArgs: [projectId],
    );

    a.title = titleController.text.trim();
    a.content = deltaJson;

    lastSaved = DateTime.now();
    refreshUI();

    _infoboxDirty = false;
    originalContent = deltaJson;
    originalTitle = titleController.text;
  }

  // ═══════════════════════════════════════════════════════════
  // TABLE OF CONTENTS
  // ═══════════════════════════════════════════════════════════

  void rebuildTocFromContent() {
    tocEntries.clear();
    
    final doc = contentController.document;
    int headingIndex = 0;
    int charOffset = 0;

    for (final node in doc.root.children) {
      final style = node.style.attributes['header'];
      
      if (style != null && style.value == 2) {
        final text = node.toPlainText().trim();
        if (text.isNotEmpty) {
          final id = 'h_$headingIndex';
          tocEntries.add(
            TocEntry(id: id, title: text, textOffset: charOffset),
          );
          headingIndex++;
        }
      }
      
      charOffset += node.length;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // INFOBOX BLOCKS
  // ═══════════════════════════════════════════════════════════

  Future<void> _loadInfoboxBlocks(Article article) async {
    final db = await AppDatabase.database;
    final rows = await db.query(
      'infobox_blocks',
      where: 'article_id = ?',
      whereArgs: [article.id],
      orderBy: 'position ASC',
    );

    article.infoboxBlocks
      ..clear()
      ..addAll(
        rows.map((row) {
          final type = InfoboxBlockType.values.firstWhere(
            (t) => t.name == row['type'],
          );
          return InfoboxBlock.fromJson(type, jsonDecode(row['data'] as String));
        }),
      );
  }

  Future<void> saveInfoboxBlocks(Article article) async {
    final db = await AppDatabase.database;

    await db.delete(
      'infobox_blocks',
      where: 'article_id = ?',
      whereArgs: [article.id],
    );

    for (int i = 0; i < article.infoboxBlocks.length; i++) {
      final block = article.infoboxBlocks[i];

      await db.insert('infobox_blocks', {
        'id': '${article.id}_$i',
        'article_id': article.id,
        'type': block.type.name,
        'data': jsonEncode(block.toJson()),
        'position': i,
      });
    }
  }
}

class TocEntry {
  final String id;
  final String title;
  final int textOffset;

  TocEntry({required this.id, required this.title, required this.textOffset});
}
